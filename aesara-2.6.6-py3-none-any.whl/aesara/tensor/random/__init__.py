# Initialize `RandomVariable` optimizations
import aesara.tensor.random.opt
import aesara.tensor.random.utils
from aesara.tensor.random.basic import *
from aesara.tensor.random.op import RandomState, default_rng
from aesara.tensor.random.utils import RandomStream
